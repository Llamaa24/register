package com.example.project;

import java.util.List;
import java.util.List;

public class Section {
    private String name;
    private List<Classroom> classrooms;

    public Section(String name, List<Classroom> classrooms) {
        this.name = name;
        this.classrooms = classrooms;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Classroom> getClassrooms() {
        return classrooms;
    }

    public void setClassrooms(List<Classroom> classrooms) {
        this.classrooms = classrooms;
    }
}
