package com.example.project;

public class BookingService {
    public boolean bookClassroom(Classroom classroom) {
        if ("Available".equals(classroom.getStatus())) {
            classroom.setStatus("Not Available");
            // Update the database here
            return true;
        }
        return false;
    }
}
